<html>
<head>
<title>Latihan 1</title>
</head>
<body>

<form>
    Masukan Nama : <input type="text" name=""  size="25">
    <input type="submit" value="Proses">
</form>
</body>

</html>