<html>
<head>
<title>Latihan 3 POST</title>
</head>
<body>
<form action="tampilprosespost.php" method="post">
    Masukan Nama Kampus Anda: <input type="text" name="nama_kampus"  size="25">
    <input type="submit" value="Proses">
</form>
</body>

</html>