<html>
<head>
    <title>DATA MAHASISWA</title>
</head>
<body>
<form action="tampildatamhs.php" method="post">
<h1>DATA MAHASISWA</h1>
<br>

<pre>
Nim     :  <input type="text" name="nimmhs" size="25" maxlength="50">
Nama    :  <input type="text" name="namamhs" size="25" maxlength="50">
Alamat  :  <textarea name="alamat" size="25" maxlength="50"></textarea>  
</pre>
Jenis Kelamin :
<input type="radio" name="jeniskel" value="Laki-Laki">Laki-Laki
<input type="radio" name="jeniskel" value="Perempuan">Perempuan

<p>
Mata Kuliah :
<select name="matakuliah">
<option value="-PILIH MATA KULIAH-"></option>
<option value="WEB PROGRAMING 1">WEB PROGRAMING 1</option>
<option value="LOGIKA ALGORITMA">LOGIKA ALGORITMA</option>
<option value="APSI">APSI</option>
<option value="BAHASA INGGRIS">APSI</option>
<option value="DBMS">APSI</option>
</select>
</p>
Jurusan : 
<input type="checkbox" name="jurusan1" value="Sistem Informasi">Sistem Informasi
<input type="checkbox" name="jurusan2" value="Perkantoran">Perkantoran
<input type="checkbox" name="jurusan3" value="Teknik Informatika">Teknik Informatika

<br>
<input type="submit" value="Kirim">
<input type="reset" value="Batal">
</form>
</body>
</html>