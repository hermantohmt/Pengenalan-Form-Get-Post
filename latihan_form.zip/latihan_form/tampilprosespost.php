<html>
    <head><title>Hasil Proses POST</title></head>
    <body>
DATA NAMA KAMPUS YANG DIINPUTKAN ADALAH : <?php echo $_POST["nama_kampus"];?>
    </body>
</html>