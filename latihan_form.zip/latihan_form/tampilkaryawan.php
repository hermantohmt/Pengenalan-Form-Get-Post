<html>
<head>
    <title>DATA KARYAWAN</title>
</head>    
<body>
<?php

$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$Tanggal=$_POST['tanggal'];
$jenkel=$_POST['jeniskel'];
$pendudikan=$_POST['pendidikan'];

?>

<table border="1">

<tr>
    <td><B>DATA KARYAWAN BARU</B></td>
</tr>

<tr>
    <td> Nama</td>
    <td><?php echo $nama ?> </td>
</tr>

<tr>
    <td> alamat</td>
    <td><?php echo $alamat ?> </td>
</tr>

<tr>
    <td> Tanggal Lahir</td>
    <td><?php echo $Tanggal ?> </td>
</tr>

<tr>
    <td> Jenis Kelamin</td>
    <td><?php echo $jenkel ?> </td>
</tr>

<tr>
    <td>Pendudikan</td>
    <td><?php echo $pendudikan ?> </td>
</tr>


</table>
<a href="latihan5.php">Input Data Lagi</a>
    </body>
</html>s