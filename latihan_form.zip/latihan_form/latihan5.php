<html>
    <head><title>DATA KARYAWAN BARU</title></head>

    <body>
        <form action="tampilkaryawan.php" method="post">
            <p style="text-align: left; font-weight: bold; font-size: 24px; "> FORMULIR KARYAWAN BARU</p>
            <table width="50%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td colspan="2" style="font-size: 16;">
                        Isi Data dibawah ini dengan lengkap: 
                    </td>
                </tr>
                <tr>
                    <td width="48%"> Nama</td>
                    <td width="52%"><input type="text" name="nama"> </td>
                </tr>

                <tr>
                    <td style="font-size: 16;"> Alamat</td>
                    <td style="font-size: 16;"><textarea name="alamat"></textarea> </td>
                </tr>

                <tr>
                    <td style="font-size: 16;">Tanggal Lahir</td>
                    <td style="font-size: 16;"> <input type="date" name="tanggal"> </td>
                </tr>

                <tr>
                    <td style="font-size: 16;"> Jenis Kelamin</td>
                    <td style="font-size: 16;"> <input type="radio" name="jeniskel" value="Laki-Laki">Laki-Laki
                   <input type="radio" name="jeniskel" value="Perempuan">Perempuan
                
                </td>
                </tr>

                <tr>
                    <td style="font-size: 16;"> Pendidikan </td>
                    <td style="font-size: 16;">
                <select name="pendidikan">
                    <option value="">Pilih Pendidikan</option>
                    <option value="D3">D3</option>
                    <option value="S2">S1</option>
                    <option value="S2">S2</option>
                    <option value="S3">S2</option>
                    <option value="Lainnya">Lainnya</option>


                </select>
                
                </td>
                </tr>

                <tr>
                <td style="font-size: 16;" colspan="2">
                <input type="submit" value="Simpan"> 
                <input type="reset" value="Batal"> 

            
            </td>

                </tr>
            </table>






        </form>

    </body>
</html>