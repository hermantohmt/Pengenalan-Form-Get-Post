<html>
<head>
<title>Latihan 2</title>
</head>
<body>
<form action="tampilprosesget.php" method="get">
    Masukan Nama : <input type="text" name="nama"  size="25">
    <input type="submit" value="Proses">
</form>
</body>

</html>