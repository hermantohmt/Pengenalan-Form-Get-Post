<html>
<head>
    <title>DATA HASIL INPUT MAHASISWA</title>
</head>    
<body>
<?php
$nim=$_POST['nimmhs'];
$nama=$_POST['namamhs'];
$alamat=$_POST['alamat'];
$jenkel=$_POST['jeniskel'];
$makul=$_POST['matakuliah'];
$jurusan1=$_POST['jurusan1'];
$jurusan2=$_POST['jurusan2'];
$jurusan3=$_POST['jurusan3'];
?>

<table border="1">

<tr>
    <td><B>DATA MAHASA SISWA</B></td>
</tr>

<tr>
    <td> Nim</td>
    <td><?php echo$nim ?> </td>
</tr>

<tr>
    <td> Nama</td>
    <td><?php echo $nama ?> </td>
</tr>

<tr>
    <td> alamat</td>
    <td><?php echo $alamat ?> </td>
</tr>

<tr>
    <td> Jenis Kelamin</td>
    <td><?php echo $jenkel ?> </td>
</tr>

<tr>
    <td> Mata Kuliah</td>
    <td><?php echo $makul ?> </td>
</tr>
<tr>
    <td>Jurusan</td>
    <td><?php echo $jurusan1, $jurusan2, $jurusan3 ?> </td>
</tr>

</table>
<a href="latihan4.php">Input Data Lagi</a>
    </body>
</html>