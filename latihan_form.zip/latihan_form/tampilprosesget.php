<html>
    <head><title>Hasil Proses Get</title></head>
    <body>
DATA NAMA YANG DIINPUTKAN ADALAH :<?php echo $_GET["nama"];?>
    </body>
</html>